SP：single port 单端口模式，即半双工模式。



![image-20230228201228444](README.assets/image-20230228201228444.png)