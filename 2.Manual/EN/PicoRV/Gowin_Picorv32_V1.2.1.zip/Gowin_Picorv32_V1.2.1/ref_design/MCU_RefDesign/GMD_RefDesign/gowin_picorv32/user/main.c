/*
 * *****************************************************************************************
 *
 * 		Copyright (C) 2014-2020 Gowin Semiconductor Technology Co.,Ltd.
 *
 * @file		main.c
 * @author		Embedded Development Team
 * @version		V1.2
 * @date		2020-6-30 09:00:00
 * @brief		Main body.
 ******************************************************************************************
 */

/* Includes --------------------------------------------------------------------- */
#include "config.h"
#include "picorv32.h"
#include "firmware.h"
#include "simpleuart.h"
#include "wbuart.h"
#include "wbgpio.h"
#include "irq.h"
#include "advspi.h"
#include "open_ahb.h"
#include "open_wb.h"

#ifdef USE_WBUART
#define get_char()   wbuart_getc()
#define put_char(c)  wbuart_putc(c)
#else
#define get_char()   uart_getchar()
#define put_char(c)  uart_putchar(c)
#endif

extern uint32_t irq_mask;

uint8_t tx_buffer[100] = {0,1,2,3,4,5,6,7,8,9};
uint8_t rx_buffer[100] = {0};

int get_int_lt_100(void);
void spi_flash_demo(void);
void wbreg_demo(void);
void gpio_demo(void);
void ahbreg_demo(void) __attribute__((optimize("O0"))) ;


int __attribute__((optimize("O0"))) main(void)
{
	irq_mask = ~((1 << 20) + (1 << 21) + (1 << 3) + (1 << 2) + (1 << 0));
	mask_irq(irq_mask);

	wbuart_init(115200);
	spi_flash_init();
	GPIO_Init(PICO_WBGPIO);
	
	//enable interrupt
	__asm__ __volatile__("li t4, 0x800");
	__asm__ __volatile__("csrrs t5, mie, t4");  //enable external interrupt
	__asm__ __volatile__("csrrwi t5, mstatus, 8");
	
	printf("\r\n-------------GowinSemi Gowin_PicoRV32 MCU Demo----------------\r\n");

	printf("\r\nGowin_PicoRV32 MCU Demo Beginning...\r\n");

#if BUILD_MODE == BUILD_LOAD
	printf("\r\nMCU boot from and run in ITCM.\r\n");
#endif

#if BUILD_MODE == BUILD_BURN
	printf("\r\nMCU boot from external flash and run in ITCM.\r\n");
#endif

#if BUILD_MODE == BUILD_XIP
	printf("\r\nMCU boot from and run in external flash.\r\n");
#endif

	delay(SYSCLKFREQ >> 1);

	wbreg_demo();//open wishbone interface demo
	ahbreg_demo();//open ahb interface demo
	spi_flash_demo();//adv spi-flash demo
	gpio_demo();//gpio demo

	stats();

	printf("\r\nGowin_PicoRV32 MCU Demo Finished!\r\n");

	//water light...
	while(1)
	{
		GPIO_SetDir(PICO_WBGPIO,0xffffffff);

		GPIO_WriteData(PICO_WBGPIO,0xFFFFFFFE);
		delay(SYSCLKFREQ >> 1);

		GPIO_WriteData(PICO_WBGPIO,0xFFFFFFFD);
		delay(SYSCLKFREQ >> 1);

		GPIO_WriteData(PICO_WBGPIO,0xFFFFFFFB);
		delay(SYSCLKFREQ >> 1);

		GPIO_WriteData(PICO_WBGPIO,0xFFFFFFF7);
		delay(SYSCLKFREQ >> 1);
	}

	return 0;
}

void wbreg_demo(void)
{
	uint32_t reg0 = 0x12345678;
	uint16_t reg1 = 0x1234;
	uint8_t  reg2 = 0x12;

	uint32_t reg0_readback = 0;
	uint16_t reg1_readback = 0;
	uint8_t  reg2_readback = 0;

	printf("Open Wishbone bus interface demo beginning...\r\n");

	printf("Read and write register block whose base address is 0x20000000\r\n");
	PICO_WBREGDEMO0->REG0 = reg0;
	PICO_WBREGDEMO0->REG1 = reg1;
	PICO_WBREGDEMO0->REG2 = reg2;
	printf("WB reg0 is %x,  WB reg1 is %x, WB reg2 is %x\r\n", PICO_WBREGDEMO0->REG0, PICO_WBREGDEMO0->REG1, PICO_WBREGDEMO0->REG2);

	reg0_readback = PICO_WBREGDEMO0->REG0;
	reg1_readback = PICO_WBREGDEMO0->REG1;
	reg2_readback = PICO_WBREGDEMO0->REG2;
	printf("WB reg0 readback is %x, WB reg1 readback is %x, WB reg2 readback is %x\r\n", reg0_readback, reg1_readback, reg2_readback);

	printf("Open Wishbone bus interface demo finished.\r\n");
	printf("\r\n");

	return;
}

void spi_flash_demo(void)
{
	printf("ADV SPI-Flash demo beginning...\r\n");
	printf("spi memmap");
	uint32_t *memmap_ptr = (uint32_t *)(0x10400000);
	uint32_t tmp = 0;
	printf("read flash in memory map mode:\r\n");
	for(int i = 0; i < 100; i++)
	{
		tmp = *memmap_ptr;
		printf("%08x ", tmp);
		memmap_ptr++;
	}
	printf("\r\n");

	//init tx buffer
	for(int i = 0; i < 100; i++)
	{
		tx_buffer[i] = i;
	}
	change_mode_spi_flash();

	//first read the data from flash
	printf("\r\nWe will read from init data:\r\n");
	spi_flash_read(100,0x03,0x410000,rx_buffer);
	for(int i =0 ; i< 100; i ++ )
	{
		printf("%02x ",rx_buffer[i]);
	}
	printf("\r\n");

	//and erase the sector
	printf("\r\nerase spi-flash\r\n");
	spi_flash_sector_erase(0x410000);
	printf("after erase the data is\r\n");
	//second read the data from flash
	spi_flash_read(100,0x03,0x410000,rx_buffer);
	for(int i =0 ; i< 100 ; i ++ )
	{
		printf("%02x ",rx_buffer[i]);
	}
	printf("\r\n");

	//Write data to spi flash
	printf("\r\nWe will page program the page\r\n");
	spi_flash_page_program(100,0x410000,tx_buffer);
	//read the data we write
	printf("We will read after page program data\r\n");
	spi_flash_read(100,0x03,0x410000,rx_buffer);

	for(int i = 0 ; i < 100 ; i ++ )
	{
		printf("%02x ",rx_buffer[i]);
		if(rx_buffer[i] % 16 == 0)
		{
			printf("\r\n");
		}
	}
	printf("\r\n");


	memmap_ptr = (uint32_t *)(0x10410000);
	uint32_t tmp_word = 0;
	printf("\r\nread flash in memory map mode:\r\n");
	for(int i = 0; i < 100; i++)
	{
		tmp_word = *memmap_ptr;
		printf("%08x ", tmp_word);
		memmap_ptr++;
	}
	printf("\r\n");

	printf("\r\nADV SPI-Flash demo finished.\r\n");
	printf("\r\n");

	return;
}

void gpio_demo(void)
{
	uint32_t i = 0;

	printf("Wishbone GPIO demo beginning...\r\n");

	GPIO_SetDir(PICO_WBGPIO,0xffffffff);

	while(i < 10)
	{
		GPIO_WriteData(PICO_WBGPIO,0xFFFFFFF0);
		delay(SYSCLKFREQ >> 1);

		GPIO_WriteData(PICO_WBGPIO,0xFFFFFFFF);
		delay(SYSCLKFREQ >> 1);

		i++;
	}

	printf("Wishbone GPIO demo finished.\r\n");
	printf("\r\n");
}

int get_int_lt_100(void)
{
	printf("\r\nPlease input a positive integer less than 100 \npress any key to finish:\r\n");
	int result = 0;
	int cnt = 0;
	char tmp = '\0';
	char int_str[2] = {'0'};
	for(cnt = 0; cnt < 2; cnt++)
	{
		tmp = get_char();
		if(tmp < '0' || tmp > '9')
		{
			int_str[1-cnt] = '\0';
			break;
		}
		else
		{
			put_char(tmp);
			int_str[1-cnt] = tmp;
		}
	}

	if(int_str[1] == '\0')
	{
		result = 0;
	}
	else if(int_str[0] == '\0')
	{
		result = int_str[1] - '0';
	}
	else
	{
		result = int_str[0] + int_str[1] * 10 - 528;
	}
	return result;
}

void ahbreg_demo(void)
{
	uint32_t tmp0 = 0x01234567;
	uint32_t tmp1 = 0x89abcdef;
	uint32_t rdbk = 0;

	printf("Open AHB bus interface demo beginning...\r\n");

	PICO_AHBREGDEMO->REG0 = tmp0;
	PICO_AHBREGDEMO->REG1 = tmp1;

	rdbk = PICO_AHBREGDEMO->REG0;
	printf("ahbreg0 is  %08x\r\n", rdbk);

	rdbk = PICO_AHBREGDEMO->REG1;
	printf("ahbreg1 is %08x\r\n", rdbk);

	printf("Open AHB bus interface demo finished\r\n");
	printf("\r\n");

	return;
}
