/*
 * *****************************************************************************************
 *
 * 		Copyright (C) 2014-2020 Gowin Semiconductor Technology Co.,Ltd.
 *
 * @file		open_wb.h
 * @author		Embedded Development Team
 * @version		V1.2
 * @date		2020-6-30 09:00:00
 * @brief		Open WB definition
 ******************************************************************************************
 */

#ifndef __OPEN_WB_H
#define __OPEN_WB_H

/* Includes --------------------------------------------------------------------- */
#include "picorv32.h"

/* Open WB Register Definitions --------------------------------------------------------------------- */
typedef struct {
	__IO unsigned int REG0;  //0x00
	__IO unsigned int REG1;  //0x04
	__IO unsigned int REG2;  //0x08
} WBREGDEMO_RegDef;

/* Address Definitions --------------------------------------------------------------------- */
#define WBREGDEMO0_BASE         _IO_(0x20000000)

#define PICO_WBREGDEMO0        ((WBREGDEMO_RegDef   *)    WBREGDEMO0_BASE )

#endif
