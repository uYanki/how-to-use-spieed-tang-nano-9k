--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
            Copyright (C) 2014-2021 Gowin Semiconductor Technology Co.,Ltd.
                                All rights reserved.
--------------------------------------------------------------------------------------------
							   Gowin_PicoRV32 Read Me
--------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------
1. Software Environment
	Gowin_V1.9.8Beta
	GMD V1.1
--------------------------------------------------------------------------------------------
2. Hardware Environment
	DK-START-GW2A18 V2.0
	DK-START-GW2A55 V1.3
	DK-START-GW2AR18 V1.1
	DK-START-GW1N9 V1.1
--------------------------------------------------------------------------------------------
3. Files
|-- doc										--> Documents
|	|-- ReadMe.txt							--> Read me file
|	|-- ReleaseNote.txt						--> Release note file
|-- ref_design								--> Reference design
|	|-- FPGA_RefDesign						--> FPGA RTL reference design
|	|	|-- ReadMe.txt						--> Read me
|	|	|-- DK_START_GW2A18_V2.0			--> Reference design of DK-START-GW2A18 V2.0
|	|	|	|-- gowin_picorv32				--> Hardware reference design
|	|	|	|-- ReadMe.txt					--> Read me
|	|-- MCU_RefDesign						--> MCU C reference design
|	|	|-- ReadMe.txt						--> Read me
|	|	|-- GMD_RefDesign					--> Reference design of GOWIN MCU Designer
|	|	|	|-- gowin_picorv32				--> Software reference design
|	|	|	|-- ReadMe.txt					--> Read me
|-- tool									--> Download script
|	|-- makehex								--> make hex tool
|	|-- mergebin							--> merge bin tool
|-- src										--> MCU source library
|	|-- c_lib								-->	MCU C source library
|	|-- ReadMe.txt							--> ReadMe.txt
--------------------------------------------------------------------------------------------
4. Manuals
	Download from http://www.gowinsemi.com.cn/
		1) Gowin_PicoRV32硬件设计参考手册.pdf
		2) Gowin_PicoRV32软件下载参考手册.pdf
		3) Gowin_PicoRV32软件编程参考手册.pdf
		4) Gowin_PicoRV32快速设计参考手册.pdf
		5) Gowin_PicoRV32 IDE软件参考手册.pdf
	Download from https://www.gowinsemi.com/en/
		1) Gowin_PicoRV32 Hardware Design Reference Guide.pdf
		2) Gowin_PicoRV32 Software Download Reference Guide.pdf
		3) Gowin_PicoRV32 Software Programming Reference Guide.pdf
		4) Gowin_PicoRV32 Quick Design Reference Guide.pdf
		5) Gowin_PicoRV32 IDE Software Reference Guide.pdf
--------------------------------------------------------------------------------------------