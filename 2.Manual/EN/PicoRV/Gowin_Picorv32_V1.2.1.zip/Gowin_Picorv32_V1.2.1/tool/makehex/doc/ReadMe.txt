----------------------------------------------------------------------------
Copyright (C) 2014-2021 Gowin Semiconductor Technology Co.,Ltd.   
                    All rights reserved.
----------------------------------------------------------------------------
run makehex32.exe through dos command line
run makehex08.exe through dos command line
----------------------------------------------------------------------------
1. makehex32.exe bin-file
   makehex08.exe bin-file
----------------------------------------------------------------------------
2. switch bin-file into a hex-file : ram32.hex or ram08.hex
----------------------------------------------------------------------------
3. Files
|-- bin					--> Executed files
|--|-- makehex08.exe	--> makehex08
|--|-- makehex32.exe	--> makehex32
|-- doc					--> Documents
|--|-- ReadMe.txt		--> Read me
----------------------------------------------------------------------------