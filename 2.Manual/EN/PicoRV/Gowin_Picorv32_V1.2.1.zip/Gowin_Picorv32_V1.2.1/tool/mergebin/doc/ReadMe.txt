--------------------------------------------------------------
Copyright (C) 2014-2021 Gowin Semiconductor Technology Co.,Ltd.   
                    All rights reserved.
--------------------------------------------------------------
run mergebin.bat through dos command line
--------------------------------------------------------------
1. mergebin.bat calls posp_parse.exe and merge_bit.exe
--------------------------------------------------------------
2. posp_parse.exe posp-file itcm-size gwsyn
   generate BramLoc.txt
   input posp-file
   set itcm size(8KB, 16KB, 32KB, 64KB, 128KB, 256KB)
   set synthesis tool (gowin_syn)
--------------------------------------------------------------
3. merge_bit.exe bin-file BramLoc.txt fs-file
   merge fs-file and bin-file into a new fs-file
--------------------------------------------------------------
4. Files
|-- bin						--> Executed files
|--|-- merge_bit.exe		--> Merge bit
|--|-- posp_parse.exe	--> Parse posp-file
|-- doc						--> Documents
|--|-- ReadMe.txt			--> Read me
--------------------------------------------------------------