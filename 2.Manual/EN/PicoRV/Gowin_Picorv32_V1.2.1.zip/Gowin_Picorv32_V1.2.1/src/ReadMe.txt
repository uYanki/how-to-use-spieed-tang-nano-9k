--------------------------------------------------------------------------
Copyright (C) 2014-2021 Gowin Semiconductor Technology Co.,Ltd.
                    	All rights reserved.
--------------------------------------------------------------------------
c_lib is for Gowin_PicoRV32 software programming.
--------------------------------------------------------------------------
Including in library : 
1. bootloader	    (startup)
2. system		    (firmware, interrupt, initialization and clock)
3. registers	    (peripherals, address)
4. drivers		    (GPIO, UART, I2C, SPI Master/Slave, SPI-Flash)
5. configuration    (boot mode)
6. linker           (boot and memory)
--------------------------------------------------------------------------
MCU IDE
1. GMD V1.1
--------------------------------------------------------------------------