----------------------------------------------------------------------------------------
			Copyright (C) 2014-2021 Gowin Semiconductor Technology Co.,Ltd.   
								All rights reserved.
----------------------------------------------------------------------------------------
					      Gowin_PicoRV32 C Library Read Me                                  
----------------------------------------------------------------------------------------
c_lib
	/doc											//Read me and release note
		/ReadMe.txt									//Read me
		/ReleaseNote.txt							//Release note
	/lib											//Library Files
		/config										//User configuration
			/config.h								//User configuration
		/startup									//Start up
			/custom_ops.S							//Customer options
			/start.S								//Start up
		/peripherals								//Peripheral Drivers
			/includes								//Driver Header Files
				/simpleuart.h						//Simple UART
				/wbi2c.h							//Wishbone I2C
				/wbspi.h							//Wishbone SPI
				/wbuart.h							//Wishbone UART
				/advspi.h							//ADV SPI-Flash
				/wbgpio.h							//Wishbone GPIO
			/sources								//Driver Source Files
				/simpleuart.c						//Simple UART
				/wbi2c.c							//Wishbone I2C
				/wbspi.c							//Wishbone SPI
				/wbuart.c							//Wishbone UART
				/advspi.c							//ADV SPI-Flash
				/wbgpio.c							//Wishbone GPIO
		/system										//System
			/firmware.c								//Firmware
			/irq.c									//Interrupt
			/picorv32.h								//Registers
			/config.h								//Boot mode configuration
			/loader.c								//Boot mode
		/linker										//Linker
			/sections.lds							//ITCM Flash linker
			/sections_xip.lds						//External Flash linker
			/sections_debug.lds						//Debug Flash linker
		/template									//Template
			/printf.c								//Print
			/main.c									//Main body
			/open_ahb.h								//AHB bus extension example
			/open_wb.h								//Wishbone bus extension example
----------------------------------------------------------------------------------------